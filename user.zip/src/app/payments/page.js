import React from "react";
import PaymentDetail from "@/components/payments/paymentDetail";

export default function Page() {
  return (
    <>
      <PaymentDetail />
    </>
  );
}
