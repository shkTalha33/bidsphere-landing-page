import PaymentStatics from "@/components/payments/paymentStatics";

export default function Page() {
  return (
    <main className="bg_mainsecondary p-4">
      <PaymentStatics />
    </main>
  );
}
