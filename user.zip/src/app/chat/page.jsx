"use client";
import React from "react";
import Chat from "../../components/messages/message";
const Page = () => {
  return (
    <>
      {" "}
      <Chat />
    </>
  );
};

export default Page;
