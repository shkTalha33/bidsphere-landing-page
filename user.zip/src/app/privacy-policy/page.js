import { Container } from 'react-bootstrap'

const Page = () => {
    return (

        <>
            <Container fluid='sm'>
                <section className=' sm:mt-6 pt-3'>

                </section>
            </Container>
        </>
    )
}

export default Page