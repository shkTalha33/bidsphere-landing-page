import NoMatch from '@/components/snackbar/nomatch'

export default function NotFound() {
    return (
        <>
            <NoMatch />
        </>
    )
}