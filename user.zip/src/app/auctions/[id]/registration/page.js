import RegistrationDetail from "@/components/auction/auctionRegistration.jsx/registrationDetail";
import React from "react";

const Page = () => {
  return (
    <main className="bg_mainsecondary p-2 md:py-4">
      <RegistrationDetail />
    </main>
  );
};

export default Page;
