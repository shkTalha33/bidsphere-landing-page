import AllAuction from "@/components/auction/allAuction";
import React from "react";

export default function Page() {
  return (
    <>
      <AllAuction />
    </>
  );
}
